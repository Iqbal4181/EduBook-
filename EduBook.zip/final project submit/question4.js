const quiz=[
    {
        q:'Which of the following national parks is not listed in a UNESCO World Heritage site?',
        options:
        ["Kaziranga",
        "Keoladeo",
        "Sundarbans",
        "Kanha"
      ],
        answer:3

    },
    {
        q:'The capital of Uttarakhand is...',
        options:
        ["Masoorie",
        "Dehra Dun",
        "Nainital",
        "None of these"
      ],
        answer:1

    },
    {
        q:'In which state has the largest area?',
        options:
        ["Maharashtra",
        "Madhya Pradesh",
        "Uttar Pradesh",
        "Rajasthan"
      ],
        answer:3

    },
    {
        q:' Geet Govind is a famous creation of ...',
        options:
        ["Bana Bhatt",
        "Kalidas",
        "Jayadev",
        "Bharat Muni"
      ],
        answer:2

    },
    {
        q:'Galileo was an Italian astronomer who...',
        options:
        ["developed the telescope",
        "discovered four satellites of Jupiter",
        "discovered that the movement of pendulum produces a regular time measurement",
        "All of the above"
      ],
        answer:3

    },
    {
        q:'The Maratha and The Kesri were the two main newspapers which were started by the following people?',
        options:
        ["Lala Lajpat Rai",
        "Gopal Krishna Gokhale",
        "Bal Gangadhar Tilak",
        "Madan Mohan Malviya"
      ],
        answer:2

    },
    {
        q:'When did the World Trade Organization come into existence',
        options:
        ["1992",
        "1993",
        "1994",
        "1995"
      ],
        answer:3

    },
    {
        q:'Exposure to sunlight helps a person to improve his health because...',
        options:
        ["(A) the infrared light kills bacteria in the body",
        "resistance power increases",
      "the pigment cells in the skin get stimulated and produce a healthy tan",
      "the ultraviolet rays convert skin oil into Vitamin D"
      ],
        answer:3

    },
    {
        q:'The Lucknow session of Indian National Congress that took place in 1916 was presided by__?',
        options:
        ["Rashbihari Ghosh",
        "Ambika Charan Majumdar",
        "Bhupendra Nath Bose",
        "None of the above"
      ], 
        answer:1 

    },
    {
        q:'In which year did the Cabinet Mission arrived in India?',
        options:
        ["1942",
        "1943",
        "1945",
        "1946"
      ],
        answer:3

    },
    {
        q:'Golf player Vijay Singh belongs to which country?',
        options:
        ["USA",
        "Fiji",
        "India",
        "UK"
      ],
        answer:1

    },
    {
        q:'When did the first Afghan war happen?',
        options:
        ["1839",
        "1843",
        "1833",
        "1848"
      ],
        answer:0

    },
    {
        q:'Gulf cooperation council was originally formed by ?',
        options:
        ["Bahrain, Kuwait, Oman, Qatar, Saudi Arabia and United Arab Emirates",
        "Second World Nations",
        "Third World Nations",
        " Fourth World Nations"
      ],
        answer:0

    },
    {
        q:' For Olympic and World tournaments, the basketball court has dimensions...',
        options:
        ["26 m x 14 m",
        "28 m x 15 m",
        "27 m x 16 m",
        "28 m x 16 m"
      ],
        answer:1

    },
    {
        q:' Panini was……',
        options:
        ["a Greek philosopher",
        "an Indian astronomer and famous mathematician",
        "a Sanskrit grammarian of Vedic times",
        "great poet of ancient times."
      ],
        answer:2

    },
    {
        q:'The winners of which game are honored: Federation Cup, World Cup, Alvin International Trophy and Challenge Cup?',
        options:
        ["Tennis",
        "Volleyball",
        "Basketball",
        "Cricket"
      ],
        answer:1

    },
    {
        q:'Under which of the following trees, Buddha got enlightment?',
        options:
        ["Ficus benghalensis",
        "Ficus religiosa",
        "Ficus microcarpa",
        "Ficus elastica"
      ],
        answer:1

    },
    {
        q:'Which of the following is the world’s largest and deepest ocean?',
        options:
        ["Arctic",
        "Atlantic",
        "Pacific",
        "Indian"
      ],
        answer:2

    },

    {
        q:'World Red Cross and Red Crescent Day are celebrated every year',
        options:
    ["may 8",
      "may 18",
      "june 8",
      "june 18"
    ],
        answer:0

    },

    {
        q:'Eritrea, which became the 182nd member of the United Nations in 1993, is on the continent of',
        options:
        ["Asia",
        "Africa",
        "Europe",
        "Australia"
      ],
        answer:1

    },

    {
        q:'National emergency arising out of war, armed rebellion or external aggression, belongs to which of the following articles?',
        options:
        ["Article 280",
        "Article 352",
        "Article 356",
        "Article 370"
      ],
        answer:1

    },

    {
        q:' Famous sculptures depicting the art of love built sometime between 950 and 1050 AD.',
        options:
        ["mizoram",
        "orissa",
        "manipur",
        "meghalaya"
      ],
        answer:0

    },
    {
        q:'In which state is the Elephant Falls located?.',
        options:
        ["greece",
        "finland",
        "norway",
        "united kingdom"
        
      ],
        answer:3

    },

    {
        q:'Friction can be reduced by changing from...',
        options:
        ["sliding to rolling",
        "rolling to sliding",
        "potential energy to kinetic energy",
        "dynamic to static"
      ],
        answer:0

    },
{
    q:'Where is the headquarters of ASEAN located?.',
    options:
    ["male",
    "kathmandu",
    "jakarta",
    "kuala lumpur"
  ],
    answer:2

},
]