<?php
session_start();

$con = mysqli_connect('localhost', 'root', '','thesis');

$txtCurrentpassword = $_POST['currentpassword'];
$txtNewpassword = $_POST['newpassword'];
$txtConfirmpassword = $_POST['cpassword'];
$txtPassword=$_SESSION['password'];
//echo $txtPassword;
$txtId=$_SESSION['id'];

// $sql = "INSERT INTO `registration` (`id`, `name`, `email` , `password`, `confirm_password`) VALUES ('0', '$txtName', '$txtEmail', '$txtPassword', '$txtConfirmPassword')";

if($txtPassword == $txtCurrentpassword)
{
    if($txtNewpassword == $txtConfirmpassword){
	$sql = "UPDATE registration SET password=$txtNewpassword,confirm_password=$txtConfirmpassword WHERE id=$txtId";
	$result = mysqli_query($con, $sql);
	if($result)
{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("password update  Successful")';  
	echo '</script>';  

 }
 else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("password update  failed")';  
	echo '</script>';  
  
 }
}
}else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("current password doesnot match")';  
	echo '</script>';  
  
 }
?>