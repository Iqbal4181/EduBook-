//array of object
const quiz = [
    {
       q:'Which month comes right before june ?',
       options:['may','september','july','august'],
       answer:0
    },
    {
        q:'What color is a banana? ?',
        options:['red','Yellow','white','blue'],
        answer:1
     },
        {
            q:'What is the population of the world ?',
            options:
            ['about 2.6 billion','about 4 billion','about 7.2 billion','about 10 billion'],
            answer:0
    
        },
        {
            q:'How many countries are there in the world ?',
            options:
            ['100','150','200','300'],
            answer:0
    
        },
        {
            q:'Which of the following countrie is the largest in size ?',
            options:
            ['Brazil','Canada','china','Russia'],
            answer:3
    
        },
        {
            q:'How many statee are in the United State of America ?',
            options:
            ['48','49','50','52'],
            answer:0
    
        },
        {
            q:'Which language is most commonly spoken in Brazil ?',
            options:
            ['Italian','Portuguese','Russian','Spanish'],
            answer:0
    
        },
        {
            q:'Which countrys flag has a picture of a tree on it ?',
            options:
            ['Canada','Greece','Lebanon','Ireland'],
            answer:0
    
        },
        {
            q:'About how many different languages are spoken in the world ?',
            options:
            ['600','1000','7000','15000'],
            answer:0
    
        },
        {
            q:'In which country is the United Nations located ?',
            options:
            ['Germany','The United kingdom','Japan','The united state'],
            answer:3
    
        },
        {
            q:'When did Christopher Columbus first visit the Americas ?',
            options:
            ['1136','1492','1648','1723'],
            answer:0
    
        },
        {
            q:'Which of the following countries has the smallest population ?',
            options:
            ['Iceland','Singapore','Mexico','Yemen'],
            answer:0
    
        },
        {
            q:'Which of the following countrie is smallest in size ?',
            options:
            ['Ireland','Japan','Egypt','Argentina'],
            answer:0
    
        },
        {
            q:'Which of this countrie does not have a coast ?',
            options:
            ['Mongolia','peru','Poland','Turkey'],
            answer:0
    
        },
        {
            q:'Which of the following continents is largest ?',
            options:
            ['Africa','Europe','North America','Asia'],
            answer:3
    
        },
        {
            q:'Which of the following countries has a king ?',
            options:
            ['Chile','Sweden','South Africa','The philippines'],
            answer:0
    
        },
        {
            q:'Which crop is sworn on the largest area in india ?',
            options:
            ['Rice','wheat','sugarcane','maiza'],
            answer:0
    
        },
        {
            q:'Garampain sanctuary is located at?',
            options:
            ['jungarh,gujrat','diphu,assam','kohima,nagaland','none of these'],
            answer:0
    
        },
        {
            q:'When did the first afghan war happen ?',
            options:
            ['1839','1843','1833','1848'],
            answer:0
    
        },
        {
            q:'When was the war ofv american independent ?',
            options:
            ['1770','1772','1774','1776'],
            answer:3
    
        },
        {
            q:'World Red cross and red crescent day are celebrated every year ?',
            options:
            ['may 8','may 18','june 8','june 18'],
            answer:0
    
        },
        {
            q:'The literacy rate of india is ?',
            options:
            ['57.86%','61.34%','63.98%','65.38%'],
            answer:3
    
        },
        {
        q:'Windows, macOS, and Linux are examples of ________.?',
        options:['web browsers','mobile devices','filmy heroines','operating systems'],
        answer:3
        },
        {
        q:'What does "GUI" stand for?',
        options:['Global user index','Graphical user interface','golu use iphone'],
        answer:1
        },
       
        {
        q:'mark zuckerberg is the owner of  ?',
        options:['facebook','google','linux','linkedin'],
        answer:0
    }
       
       
    ]