<?php

$con = mysqli_connect('localhost', 'root', '','thesis');

//session_start(); 

error_reporting(0);
$query = "SELECT question.id, question.date,question.query,registration.name FROM question INNER JOIN registration ON question.user_id = registration.id";
$data = mysqli_query($con,$query);
$total = mysqli_num_rows($data);



if($total > 0)
{
 
  $_SESSION['data']=$data;
   
}
?>