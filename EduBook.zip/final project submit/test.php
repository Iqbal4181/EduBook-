<?php
session_start();
echo "welcome".$_SESSION['num'];
?>