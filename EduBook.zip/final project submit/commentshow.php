<?php

session_start();

$con = mysqli_connect('localhost', 'root', '','thesis');











$query = "SELECT * FROM question INNER JOIN registration ON question.user_id = registration.id";
$data = mysqli_query($con,$query);
$total = mysqli_num_rows($data);



if($total > 0)
{
 
  $_SESSION['commentdata']=$data;

}

?>