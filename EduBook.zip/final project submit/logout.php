<?php
session_start();


if(session_destroy())
{

header("Location: registration and login.html");

}


?>