const quiz=[
    {
        q:' Which Indian state has its maximum area under the forest cover??',
        options:
        [" Maharashtra",
        "Madhya Pradesh",
         "Arunachal Pradesh",
        "Kerala"
            ],
        answer:2

    },
    {
        q:'When did Mother Teresa win the Nobel Peace Prize?   .',
        options:
        ["1975",
        "1979",
       "1981",
       "1982"
     ],
        answer:1

    },
    {
        q:'Coral reefs in India can be found in?',
        options:
        [" the coast of Orissa",
        "Waltair",
      "Rameshwaram",
      "Trivandrum"
      ],
        answer:2

    },
    {
        q:' Jana Gana Mana was accepted as the National Anthem of India by the Constituent Assembly of India, in which of the following years?',
        options:
        [" 1950",
        "1949",
      "1948",
      "1947"
      ],
        answer:0

    },
    {
        q:'What is the state flower of Haryana?',
        options:
        ["Lotus",
        "Rhododendron",
        "Golden Shower",
        "Not declared"
        ],
        answer:0

    },
    {
        q:'GATT (General Agreement on Tariffs and Trade) is',
        options:
        ["international agreement signed in 1947 between non-communist nations with the object of encouraging international trade unobstructed by tariff barriers",
        "agreement which seeks to achieve its aim by arranging and encouraging bargaining with trade concessions between members",
        " Both (A) and B",
        "None of the above"
        
        ],
        answer:2

    },
    {
        q:'The headquarters of Reserve Bank of India is…?',
        options:
        ["Kolkata",
        "New Delhi",
        "Mumbai",
        "Chennai"
        ],
        answer:2

    },
    {
        q:'Who is the first non-Indian to receive the Bharat Ratna?',
        options:
        ["Martin Luther King",
        "Mother Teresa",
        "Khan Abdul Ghaffar Khan",
        "Aubin Mehta"
        ],
        answer:2

    },
    {
        q:'Who was the first Indian Army Chief of the Indian Army?',
        options:
        ["Gen. K.M. Cariappa",
        "Vice-Admiral R.D Katari",
        "Gen. Maharaja Rajendra Singhji",
        "None of the above"
        ],
        answer:0

    },
    {
        q:'Where is the Tungabhadra sanctuary located?',
        options:
        [" Madhya Pradesh",
        "Uttar Pradesh",
        "Karnataka",
        "West Bengal"
        ],
        answer:2

    },
    {
        q:'Which is the largest coffee producing state of India?',
        options:
        ["Kerala",
        "Tamil Nadu",
        "Karnataka",
        "Arunachal Pradesh"
        
        ],
        answer:2

    },
    {
        q:'DRDL stands for?',
        options:
        ["Defence Research and Development Laboratary",
        "Department of Research and Development Laboratory",
        "Differential Research and Documentation Laboratary",
        "None of the above"
        ],
        answer:0

    },
    {
        q:'Mount Etna is a famous volcano which is located ?',
        options:
        ["Argentina",
        "Italy",
        "Mexico",
        "Philipines"
      ],
        answer:1

    },
    {
        q:' Which of the following is the capital of Ethiopia?',
        options:
        ["Abuja",
        "Dar es Salaam",
        "Addis Ababa",
        "Harare"
        ],
        answer:2

    },
    {
        q:'When was Goa Shipyard Limited (GSL) established',
        options:
        ["1958",
        "1957", 
          "1956",
          "1955"
          ],
        answer:1

    },
    {
        q:' Which of the following personalities is known as the father of economics?',
        options:
        [" J.M. Keynes",
        "Adam Smith",
        "Abraham Maslow",
        "J.K. Galbraith"
        ],
        answer:1

    },
    {
        q:'which state is the main language Khasi?',
        options:
        ["mizoram",
        "Nagaland",
            "Meghalaya",
            "Tripura"
            ],
        answer:2

    },
    {
        q:'What causes filariasis?',
        options:
        [" Bacteria",
        "Mosquito",
            "Protozoa",
             "Virus"
            ],
        answer:1

    },

    {
        q:'Which of the following represents the number of nations of the Non-Aligned Movement?',
        options:
        ["54",
        "75",
        "93",
        "118"
        ],
        answer:3

    },

    {
        q:'For the first time in the history of India, Mr. H. J. Kania Which of the following positions did hold?',
        options:
    ["Chief Justice of the Supreme Court of India",
  "Attorney-General of India",
    "Solicitor-General of India",
    "None of them"
    ],
        answer:0

    },

    {
        q:'In which state is the Elephant Falls located?.',
        options:
        ["greece",
        "finland",
        "norway",
        "united kingdom"
        
      ],
        answer:3

    },

    {
        q:' Famous sculptures depicting the art of love built sometime between 950 and 1050 AD.',
        options:
        ["mizoram",
        "orissa",
        "manipur",
        "meghalaya"
      ],
        answer:0

    },
    
]