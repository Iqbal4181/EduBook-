<?php

session_start();

$con = mysqli_connect('localhost', 'root', '','thesis');



$txtComment = $_POST['comment'];
$txtId=$_SESSION['id'];
$postId = $_POST['post_id'];


$sql = "INSERT INTO `comment` (`id`,`user_id`,`post_id`,`comment`) VALUES ('0','$txtId','$postId','$txtComment')";

$result = mysqli_query($con, $sql);

error_reporting(0);
$query = "SELECT * FROM question INNER JOIN registration ON question.user_id = registration.id";
$data = mysqli_query($con,$query);
$total = mysqli_num_rows($data);



if($total > 0)
{
 
  $_SESSION['data']=$data;

	header("Location: ./social site.php"); 


}


?>