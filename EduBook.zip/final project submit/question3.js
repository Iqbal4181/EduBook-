const quiz=[
    {
        q:'What Indian city is the capital of two states?',
        options:
        ["Chandigarh",
        "Kolkata",
        "Delhi",
        "Banglore"],
        answer:0

    },
    {
        q:'Which city is the capital of India?',
        options:
        ["Jaipur",
        "Delhi",
        "Chennai",
        "Mumbai"
      ],
        answer:1

    },
    {
        q:' Smallest State of India?',
        options:
        ["Rajasthan",
        "Punjab",
        "Goa",
        "Bihar"
      ],
        answer:2

    },
    {
        q:' Where is Taj Mahal Located?',
        options:
        ["Lucknow",
        "Agra",
        "Bhopal",
        "Delhi"
      ],
        answer:1

    },
    {
        q:' how many countries are there in the world?',
        options:
        ["about 100",
        "about 150",
        "about 200",
        "about 300"
      ],
        answer:2

    },
    {
        q:'which of the following countries is the largest in size?',
        options:
        ["brazil",
        "canada",
        "china",
        "russia"
      ],
        answer:3

    },
    {
        q:' what is the population of the world?',
        options:
        ["about 2.6 billion",
        "about 4 billion",
        "about 7.2 billion",
        "about 10 billion"
      ],
        answer:2

    },
    {
        q:'how many states are there in USA?',
        options:
        ["48",
        "49",
        "50",
        "52"
      ],
        answer:2

    },
    {
        q:'which language is most commonly spoken in Brazil?',
        options:
        ["itilian",
        "partuguese",
        "russian",
        "spanish"
      ],
        answer:1 

    },
    {
        q:' which countrys flag has a picture of a tree on it?',
        options:
        ["canada",
        "greece",
        "lebanon",
        "ireland"
      ],
        answer:2

    },
    {
        q:' about how many different languages are spoken in the world?',
        options:
        ["600",
        "1000",
        "6000",
        "15000"
      ],
        answer:2

    },
    {
        q:'in which country is united nations located?',
        options:
        ["germany",
        "the United Kingdom",
        "japan",
        "The United States"
       ],
        answer:3

    },
    {
        q:' When did Christopher Columbus first visit the Americas?',
        options:
        ["1136",
        "1492",
        "1648",
        "1723"
      ],
        answer:1

    },
    {
        q:' which of the following countries has smallest population ?',
        options:
        ["iceland",
        "singapore",
        "mexico",
        "yemen"
      ],
        answer:0

    },
    {
        q:' which of the following countries is smallest in size ?',
        options:
        ["ireland",
        "japan",
        "egypt",
        "argentina"
      ],
        answer:0

    },
    {
        q:'which of the following countries doesnot have a coast?',
        options:
        ["mongolia",
        "peru",
        "poland",
        "turkey"
      ],
        answer:0

    },
    {
        q:'which of the following continents is largest ?',
        options:
        ["africa",
        "europe",
        "north america",
        "asia"
      ],
        answer:3

    },
    {
        q:'which of the following countries has a king?',
        options:
        ["chile",
        "sweden",
        "south africa",
        "the philippines"
      ],
        answer:1

    },

    {
        q:'Which crop is sown on the largest area in India?',
        options:
        ["Rice",
        "Wheat",
        "Sugarcane",
        "Maize"
      ],
        answer:0

    },

    {
        q:'Eritrea, which became the 182nd member of the United Nations in 1993, is on the continent of',
        options:
        ["Asia",
        "Africa",
        "Europe",
        "Australia"
      ],
        answer:1

    },

    {
        q:'Which of the following personalities gave ‘The Laws of Heredity’?',
        options:
        ["Robert Hook",
        "G.J. Mendel",
        "Charles Darwin",
        "William Harvey"
      ],
        answer:1

    },

    {
        q:'Garampani sanctuary is located at..?',
        options:
        ["Junagarh, Gujarat",
        "Diphu, Assam",
        "Kohima, Nagaland",
        "Gangtok, Sikkim"
      ],
        answer:1

    },
    {
        q:'Grand Central Terminal, Park Avenue, New York is the world’s..."',
        options:
        ["largest railway station",
        "highest railway station",
        "longest railway station",
        "None of the above"
        
      ],
        answer:0

    },

    {
        q:'Name the person who was also known as Deshbandhu.....',
        options:
        ["S. Radhakrishnan",
        "G.K. Gokhale",
        "Chittaranjan Das",
        "Madan Mohan Malviya"
      ],
        answer:2

    },
{
    q:'FFC stands for.......',
    options:
    ["Foreign Finance Corporation",
      "Film Finance Corporation",
      "Federation of Football Council",
      "None of the above"
    ],
    answer:1

},
]