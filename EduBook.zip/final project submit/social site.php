

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social site for CSE 477 EU</title>
    <link rel="stylesheet" href="stylesocialsite.css">
    <script src="https://kit.fontawesome.com/443acaa674.js" crossorigin="anonymous"></script>
   

</head>
<body>
    <nav>
        <div class="nav-left">
            

            <a href="index.html"><img src="images/logo.png"class="logo"></a>
            
            <ul>
                <li><a href="quiz.html"><img src="images/game.png"></li></a>
                <li><img src="images/inbox.png"></li>
                <li><a href="https://youtube.com/"><img src="images/video.png"></a></li>
            </ul>
        </div>
        <div class="nav-right">
            <div class="wrapper">
                <div class="search-input">
                  <a href="" target="_blank" hidden></a>
                  <input type="text" placeholder="Type to search..">
                  <div class="autocom-box">
                    <!-- here list are inserted from javascript -->
                  </div>
                  <div class="icon"><i class="fas fa-search"></i></div>
                </div>
              </div>
            <div class="nav-user-icon online" onclick="settingsMenuToggle()">
                <img src="images/arrow1.png" >

            </div>
        </div>


        <!----dropdown-settings-menu--------->
        <div class="settings-menu">

            <div id="dark-btn">
                <span></span>
            </div>

            <div class="settings-menu-inner">

                <div class="user-profile">
                    <img src="images/arrow1.png">
                    <div>
                        <p>
                        <?php
session_start();
echo " ".$_SESSION['num'];
?>

                        </p>
                        
                    </div>
                </div>
                <hr>
    
                <div class="user-profile">
                    <img src="images/feedback.png">
                    <div>
                        <p>give feedback</p>
                        <a href="feedback.html">help us to improve the new design </a>
                    </div>
                </div>
                <hr>

               

                <div class="settings-links">
                    <img src="images/logout.png" class="settings-icon">
                    <a href="changepasswordpage.html">change password  <img src="images/arrow.png" width="10px"></a>

                </div>

                <div class="settings-links">
                    <img src="images/logout.png" class="settings-icon">
                    <a href="logout.php">Logout  <img src="images/arrow.png" width="10px"></a>

                </div>

            </div>




        </div>
    
    
    
    
    </nav>

    <div class="container">
        <!----left-sidebar--------->
        <div class="left-sidebar">
            <div class="imp-links">

                <a href="quiz.html"><img src="images/game.png">games</a>
                <a href="https://youtube.com/"><img src="images/watch.png">watch</a>

            </div>
            <div class="shortcut-links">
                <p>Your shortcuts</p>
                <a href="https://www.javatpoint.com/web-application"><img src="images/shortcut-1.png">Web Application</a>
                <a href="https://www.javatpoint.com/html-tutorial"><img src="images/shortcut-2.png">Web Design with HTML</a>
                <a href="https://www.javatpoint.com/css-tutorial"><img src="images/shortcut-2.png">Learn about CSS apply</a>
                <a href="https://www.javatpoint.com/javascript-tutorial"><img src="images/shortcut-2.png">Javascript learning in short</a>

                <a href="https://www.javatpoint.com/how-to-be-a-full-stack-developer"><img src="images/shortcut-3.png">Full Stack Devlopment</a>
                <a href="https://www.javatpoint.com/python-tutorial"><img src="images/python.png">learn python</a>
                <a href="https://www.javatpoint.com/cpp-tutorial"><img src="images/c++.png">learn c++</a>
                <a href="https://www.javatpoint.com/shell-scripting-tutorial"><img src="images/shellscript.png">learn shellscript coding</a>
            </div>
        </div>
         <!----main-content--------->

        <div class="main-content">





            <div class="post-container">
                <div class="post-row">

                    <div class="comment-box">
                        <h3>Post Your Content</h3> 
                        <form class="comment-form" action="post.php"  method="post" >
                         <textarea rows="5"  name= "query" placeholder="write something"></textarea>
                         <button type="submit" class="hero-btn">Post </button>
                        </form>
                     </div>

                </div>
                

            </div>


          
                        
                      
                        <?php
                         include("postreturn.php");
                         while($result = mysqli_fetch_assoc($_SESSION['data'])){
                            $date= $result['date'];
                              
                                
                                    $name = $result['name'];
                                    $date =  $result['date'];
                                    $query = $result['query'];
                                    $postId = $result['id'];
                                    echo "  <div class='post-container'>
                                    <div class='post-row'>
                                        <div class='user-profile'>
                                            
                                            <div> <p>$name </p>";
                                    echo " <span> $date </span>                               
                                    </div>
                                </div>
            
                            </div>             </div>";
                                    echo "<p>$query</p>";

?>
    
                                  <div class="post-container">
                                 <div class="post-row">
                 
                                     <div class="comment-box"><form action="comment.php" method="post" class="comment-form"><textarea rows="1"  name= "comment" placeholder="write your comment"></textarea> 
                                     
                                     <input type="hidden" name="post_id" value = "<?php  echo $postId ?>">
                                     <button type="submit" class="hero-btn">Post comment </button></form></div></div></div>';
                 <?php     
                                     session_start();

                                     $con = mysqli_connect('localhost', 'root', '','thesis');
                                     
                                     $query = "SELECT * FROM ((comment INNER JOIN question ON comment.post_id = question.id) INNER JOIN registration ON comment.user_id = registration.id) WHERE comment.post_id = $postId";
                                     $commentdata = mysqli_query($con,$query);
                                     $total = mysqli_num_rows($commentdata);

                                     if($total > 0){
                                     while($commentresult = mysqli_fetch_assoc($commentdata)){

                                        $comment = $commentresult['comment'];
                                        $commentname = $commentresult['name'];
                                        echo "<p>$commentname</p>";
                                        echo "<p>$comment</p>";
                                     }
                                    }
                                    }

?>
     
                             


                




            

        

          


            <button type="button" class="load-more-btn"> <a href="postreturnpage.php"> Load More</a></button>


        </div>
         <!----right-sidebar--------->
        <div class="right-sidebar">
            <div class="sidebar-title">
                <h4>Events</h4>
                <!-- <a href="#">See All</a> -->
            </div>
            <div class="event">
                <div class="left-event">
                    <h3>02</h3>
                    <span>june</span>
                </div>
                <div class="right-event">
                    <h4>5th GSCDC Nationals 2022</h4>
                    <p><i class="fa-solid fa-location-pin"></i>Government Science College</p>
                    <a href="https://www.facebook.com/events/1207119903157146/?acontext=%7B%22event_action_history%22%3A[%7B%22mechanism%22%3A%22discovery_top_tab%22%2C%22surface%22%3A%22bookmark%22%7D]%2C%22ref_notif_type%22%3Anull%7D">More Info</a>
                </div>
            </div>

            <div class="event">
                <div class="left-event">
                    <h3>04</h3>
                    <span>june</span>
                </div>
                <div class="right-event">
                    <h4>Bangladesh Environment Expo 2022 | Naturopedia</h4>
                    <p><i class="fa-solid fa-location-pin"></i>Online Event</p>
                    <a href="https://www.facebook.com/events/764570584551296/?acontext=%7B%22event_action_history%22%3A[%7B%22mechanism%22%3A%22discovery_top_tab%22%2C%22surface%22%3A%22bookmark%22%7D]%2C%22ref_notif_type%22%3Anull%7D">More Info</a>
                </div>

            </div>
            <div class="event">
                <div class="left-event">
                    <h3>28</h3>
                    <span>May</span>
                </div>
                <div class="right-event">
                    <h4>In House UK Education Expo 2022</h4>
                    <p><i class="fa-solid fa-location-pin"></i>Online Event</p>
                    <a href="https://www.facebook.com/events/968630573830483/?acontext=%7B%22event_action_history%22%3A[%7B%22extra_data%22%3A%22%22%2C%22mechanism%22%3A%22left_rail%22%2C%22surface%22%3A%22bookmark%22%7D%2C%7B%22extra_data%22%3A%22%22%2C%22mechanism%22%3A%22left_rail%22%2C%22surface%22%3A%22bookmark%22%7D%2C%7B%22extra_data%22%3A%22%22%2C%22mechanism%22%3A%22discovery_top_tab%22%2C%22surface%22%3A%22bookmark%22%7D]%2C%22ref_notif_type%22%3Anull%7D">More Info</a>
                </div>

            </div>

            








        </div>
    </div>

    <div class="footer">
        <p>Copyright 2022 By Eastern University batch 1824 Group 01 <br> Md.Iqbal Hossain <br> Nur Shalakin <br> SK Mazbahuddin Tanvir </p>

    </div>


    <script src="script.js"></script>
    <!-- <script>
        document.getElementById("demo").innerHTML = 5+6 ;
        </script> -->
</body>
</html>