<?php

$con = mysqli_connect('localhost', 'root', '','thesis');

$txtName = $_POST['name'];
$txtEmail = $_POST['email'];
$txtPassword = $_POST['password'];
$txtConfirmPassword = $_POST['confirm_password'];

// $sql = "INSERT INTO `registration` (`id`, `name`, `email` , `password`, `confirm_password`) VALUES ('0', '$txtName', '$txtEmail', '$txtPassword', '$txtConfirmPassword')";

if($txtPassword == $txtConfirmPassword)
{
	$sql = "INSERT INTO `registration` (`id`, `name`, `email` , `password`, `confirm_password`) VALUES ('0', '$txtName', '$txtEmail', '$txtPassword', '$txtConfirmPassword')";
	$result = mysqli_query($con, $sql);
	if($result)
{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Registration Successful")';  
	echo '</script>';  

 }
 else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Registration failed")';  
	echo '</script>';  
  
 }
}else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("incorrect password")';  
	echo '</script>';  
}

//$result = mysqli_query($con, $sql);



// if($result)
// {
// 	echo "Contact Records Inserted";
// }

?>