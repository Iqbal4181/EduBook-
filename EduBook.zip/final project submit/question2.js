const quiz=[
    {
        q:'Which Indian state has its maximum area under the forest cover ?',
        options:
        ['maharashtra','madhya pradesh','arunchal pradesh ','kerala'],
        answer:2

    },
    {
        q:'When did Mother Teresa win the Nobel Peace Prize ?',
        options:
        ['1975','1979','1981 ','1982'],
        answer:1

    },
    {
        q:' Coral reefs in India can be found in ?',
        options:
        ['the coast of Orissa','waltarin','Ramesharam ','Trivandrum'],
        answer:2

    },
    {
        q:' What is the state flower of Haryana ?',
        options:
        ['lotus','Rhododendron','Golden shower ','not declared'],
        answer:1

    },
    {
        q:' The headquarters of Reserve Bank of India is ?',
        options:
        ['kolkata','new delhi','mumdai ','chennai'],
        answer:2

    },
    {
        q:' Who is the first non-Indian to receive the Bharat Ratna ?',
        options:
        ['martin luther king','mother teresa','khan abdul ghaffar khan ','aubin mehta'],
        answer:2

    },
    {
        q:' Where is the Tungabhadra sanctuary located ?',
        options:
        ['madhya pradesh','uttar pradesh','karnatak ','west bengal'],
        answer:2

    },
    {
        q:'  Which is the largest coffee producing state of India ?',
        options:
        ['kerala','tamil nadu','karnatak','arunachal pradesh'],
        answer:2

    },
    {
        q:'Mount Etna is a famous volcano which is located ?',
        options:
        ['Argentina','Italy','Mexico ','Philipines'],
        answer:1 

    },
    {
        q:' Which of the following is the capital of Ethiopia ?',
        options:
        ['Abuja','Dar es salam','Addis Ababa ','Harare'],
        answer:2

    },
    {
        q:' When was Goa Shipyard Limited (GSL) established ?',
        options:
        ['1958','1957','1956 ','1955'],
        answer:1

    },
    {
        q:' Which of the following personalities is known as the father of economics ?',
        options:
        ['j.m keynes','adam smith','Abraham Maslow ','J.k Galbraith'],
        answer:1

    },
    {
        q:' which state is the main language Khasi ?',
        options:
        ['Mizoram','Nagaland','Meghalam ','Tripura'],
        answer:1

    },
    {
        q:' What causes filariasis ?',
        options:
        ['Bacteria','MOsquito','Protozoa ','virus'],
        answer:1

    },
    {
        q:' Which of the following represents the number of nations of the Non-Aligned Movement ?',
        options:
        ['54','75','93 ','118'],
        answer:3

    },
    {
        q:'  Who was the first speaker of Lok Sabha ?',
        options:
        ['k.m munish','(c)(D) deshmukh','G.v Mavalanker','H.J Kania'],
        answer:2

    },
    {
        q:'  Which bank changed its name and IFSC code for many of its branches ?',
        options:
        ['SBI','Canara Bank','Axis','Punjab National Bank'],
        answer:0

    },
    {
        q:' Which of the following ruler is known for Junagadh rock inscription ?        ?',
        options:
        ['Rudradaman I','Jivadaman','Damajadasri','Jayadaman'],
        answer:0

    },
]