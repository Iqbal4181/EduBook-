<?php

$con = mysqli_connect('localhost', 'root', '','thesis');

//$name = $_POST['name'];
//$visitor_email = $_POST['email'];
//$subject = $_POST['subject'];
//$message = $_POST['message'];

$txtName = $_POST['name'];
$txtEmail = $_POST['email'];
$txtFeedback = $_POST['feedback'];


$sql = "INSERT INTO `feedback` (`id`, `name`, `email` , `feedback`) VALUES ('0', '$txtName', '$txtEmail', '$txtFeedback')";

$result = mysqli_query($con, $sql);



if($result)
{
	header("Location: ./feedback.html");
}

?>