<?php

session_start();

$con = mysqli_connect('localhost', 'root', '','thesis');



$txtQuery = $_POST['query'];
$txtId=$_SESSION['id'];



$sql = "INSERT INTO `question` (`id`,`user_id`,`query`) VALUES ('0','$txtId','$txtQuery')";

$result = mysqli_query($con, $sql);



if($result)
{
	header("Location: ./social site.php"); 
}

?>